package Cuentas;

public abstract class ICuenta 
{
	protected String cuenta;
	protected double saldo;
	
	
	public ICuenta()
	{
	
	}

	public ICuenta(String cuenta, double saldo) 
	{
		super();
		this.cuenta = cuenta;
		this.saldo = saldo;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public abstract void abonarsaldo(double cant);
	public abstract void mostrar();
	
	
	
	

}
