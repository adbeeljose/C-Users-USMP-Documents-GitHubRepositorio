package Cuentas;

public class BancoBCP extends ICuenta
{
	public BancoBCP()
	{
		super();
		
	}
	public BancoBCP(String cuent, double sald )
	{
		super(cuent, sald);
		
	}

	@Override
	public  void abonarsaldo(double cant)
	{
		saldo= cant+saldo;
	}
	public  void mostrar()
	{	
		System.out.println("Cuenta: " + cuenta+"\nSaldo: "+ saldo+"\nBanco: BCP");
	}

}
