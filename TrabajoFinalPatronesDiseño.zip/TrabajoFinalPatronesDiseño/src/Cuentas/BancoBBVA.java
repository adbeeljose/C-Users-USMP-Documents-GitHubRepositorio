package Cuentas;

public class BancoBBVA extends ICuenta
{
	
	public BancoBBVA()
	{
		super();
	
	}
	public BancoBBVA(String cuent, double sald )
	{
		super(cuent, sald);
		
	}

	@Override
	public  void abonarsaldo(double cant)
	{
		saldo= cant+saldo;
	}
	public  void mostrar()
	{	
		System.out.println("Cuenta: " + cuenta+"\nSaldo: "+ saldo+"\nBanco: BBVA");
	}

}
