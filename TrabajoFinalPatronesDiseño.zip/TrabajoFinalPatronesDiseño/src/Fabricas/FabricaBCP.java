package Fabricas;
import Cuentas.*;
import Transacciones.*;


public class FabricaBCP extends AbstractFactory
{
	@Override
	public ICuenta getCuenta(String tipoBanco)
	{
		if (tipoBanco==null)
		{
			return null;
		}
		if(tipoBanco.equals("BCP"))
		{
			return new BancoBCP();
		}
		return null;
	}
	@Override
	public IBanco getBanco(String tipoBanco)
	{
		if (tipoBanco==null)
		{
			return null;
		}
		if(tipoBanco.equals("BCP"))
		{
			return new BCP();
		}
		return null;
	}

}
