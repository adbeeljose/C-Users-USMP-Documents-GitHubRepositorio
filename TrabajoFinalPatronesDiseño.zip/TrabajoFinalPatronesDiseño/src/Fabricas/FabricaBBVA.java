package Fabricas;

import  Cuentas.*;
import  Transacciones.*;
public class FabricaBBVA extends AbstractFactory
{
	@Override
	public ICuenta getCuenta(String tipoBanco)
	{
		if (tipoBanco==null)
		{
			return null;
		}
		if(tipoBanco.equals("BBVA"))
		{
			return new BancoBBVA();
		}
		return null;
	}
	@Override
	public IBanco getBanco(String tipoBanco)
	{
		if (tipoBanco==null)
		{
			return null;
		}
		if(tipoBanco.equals("BBVA"))
		{
			return new BBVA();
		}
		return null;
	}

}
