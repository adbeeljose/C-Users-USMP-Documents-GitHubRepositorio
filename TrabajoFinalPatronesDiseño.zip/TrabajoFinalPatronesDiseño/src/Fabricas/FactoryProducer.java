package Fabricas;

public class FactoryProducer 
{
	 public static AbstractFactory getFactory(String opcion)
	 {
		   
	      if(opcion.equals("BBVA")){
	         return new FabricaBBVA();
	         
	      }else if(opcion.equals("BCP")){
	         return new FabricaBCP();
	      }
	      
	      return null;
	   }

}
