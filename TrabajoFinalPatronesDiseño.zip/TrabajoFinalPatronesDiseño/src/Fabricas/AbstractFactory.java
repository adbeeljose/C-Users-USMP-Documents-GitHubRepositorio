package Fabricas;
import  Cuentas.*;
import  Transacciones.*;

public abstract  class AbstractFactory
{
	public abstract ICuenta getCuenta(String cuenta);
	public abstract IBanco getBanco(String banco);
	

}
