package Transacciones;

public class BBVA extends IBanco
{
	private boolean tipo;

	public BBVA()
	{
		super();
	}

	public BBVA(double monto,boolean tipo) {
		super(monto);
		this.tipo = tipo;
	}

	public boolean getTipo() {
		return tipo;
	}

	public void setTipo(boolean tipo) {
		this.tipo = tipo;
	}
	
	public void mostrar()
	{
		if(tipo)
		{
			System.out.println("Monto depositado: " + monto);
			
		}
		else
		{
			System.out.println("Monto retirado: " + monto);
		}
		System.out.println("Tipo de Banco: BBVA" );
	}
	
	
	

}
