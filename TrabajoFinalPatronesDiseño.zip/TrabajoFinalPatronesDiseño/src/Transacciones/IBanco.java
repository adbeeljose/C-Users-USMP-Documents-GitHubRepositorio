package Transacciones;

public abstract class  IBanco 
{
	protected double monto;
	

	public IBanco() {
		super();
	}

	public IBanco(double monto) 
	{
		super();
		this.monto = monto;
		
	}

	public double getMonto() {
		return monto;
	}

	public void setMonto(double monto) {
		this.monto = monto;
	}

	public abstract void mostrar();
	
	

}
