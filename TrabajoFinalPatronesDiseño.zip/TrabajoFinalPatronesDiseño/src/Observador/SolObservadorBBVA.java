package Observador;
public class SolObservadorBBVA extends Observador
{

	private double valorCambio = 3.30;
	private String promo = "Obten beneficios inmediatos con nuestras promociones, BBVA";
	
	public SolObservadorBBVA(Subject sujeto) {
		this.sujeto = sujeto;
		this.sujeto.agregar(this);
	}
	
	@Override
	public void actualizar() {		
		System.out.println("PEN: " + (sujeto.getEstado() * valorCambio)+" BCP");
		System.out.println(promo);
	}
}
