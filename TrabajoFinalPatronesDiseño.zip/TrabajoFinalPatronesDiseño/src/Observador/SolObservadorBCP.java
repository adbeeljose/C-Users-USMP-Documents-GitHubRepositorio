package Observador;

public class SolObservadorBCP extends Observador
{

		private double valorCambio = 3.25;
		private String promo = "Comuniquese con nosotros para asesorarlo, BCP siempre pensando en usted";
		public SolObservadorBCP(Subject sujeto)
		{
			this.sujeto = sujeto;
			this.sujeto.agregar(this);
		}
		
		@Override
		public void actualizar()
		{		
			System.out.println("PEN: " + (sujeto.getEstado() * valorCambio)+" BBVA");
			System.out.println(promo);
		}

}
