package Main;

import java.util.ArrayList;
import java.util.Scanner;
import Cuentas.*;
import Fabricas.*;
import Observador.*;
import Transacciones.*;

public class Fachada 
{
	private AbstractFactory fabricaBBVA;
	private AbstractFactory fabricaBCP;
	//private FactoryProducer producer = new FactoryProducer();
	private BancoBBVA cuentaBBVA;
	private BancoBCP cuentaBCP;
	private BBVA transaccionBBVA = new BBVA();
	private BCP transaccionBCP = new BCP();
	
	public ArrayList <BCP> transaccionesBCP = new ArrayList <BCP>();
	public ArrayList <BBVA> transaccionesBBVA = new ArrayList <BBVA>();
	public ArrayList <BancoBBVA> cuentasBBVA = new ArrayList <BancoBBVA>();
	public ArrayList <BancoBCP> cuentasBCP = new ArrayList <BancoBCP>();
	Scanner entradaEscaner = new Scanner (System.in);
	
	String nro, opcion;
	double saldo, x;
	public Fachada()
	{}
	public void menu()
	{
		System.out.println("Muy buenas tardes al aplicativo de la banca");
		System.out.println("Por favor, elija el banco");
		System.out.println("1- BCP");
		System.out.println("2- BBVA");
		System.out.println("Salir");
		 x= entradaEscaner.nextInt();
		while(x!=3)
		{
			if(x==1)
				opcion="BCP";
			else
				opcion="BBVA";
			ingresarBanco(opcion);
			System.out.println("Muy buenas tardes al aplicativo de la banca");
			System.out.println("Por favor, elija el banco");
			System.out.println("1- BCP");
			System.out.println("2- BBVA");
			System.out.println("Salir");
			 x= entradaEscaner.nextInt();
		}
		
		
			
	}
	public void ingresarBanco(String opcion)
	{
		System.out.println("1- Realizar transaccion");
		System.out.println("2- Registrar cuenta");
		System.out.println("3- Mostrar transaccion");
		System.out.println("4- Mostrar cuentas");
		int n = entradaEscaner.nextInt();
		
		if(opcion.equals("BCP"))
		{
			fabricaBCP = FactoryProducer.getFactory(opcion);
			cuentaBCP = (BancoBCP)fabricaBCP.getCuenta(opcion);
			transaccionBCP =(BCP)fabricaBCP.getBanco(opcion);
			if(n==2)
			{
				System.out.println("Ingrese un numero de cuenta");
				nro=entradaEscaner.nextLine();
				System.out.println("Ingrese el Saldo");
				saldo=entradaEscaner.nextInt();
				cuentaBCP.setCuenta(nro);
				cuentaBCP.setSaldo(saldo);
				cuentasBCP.add(cuentaBCP);
			}
			else if(n==1)
			{
				System.out.println("Desea realizar un deposito o un retiro");
				System.out.println("1- Realizar retiro");
				System.out.println("2- Registrar deposito");
				saldo=entradaEscaner.nextInt();
				if(saldo==1)
				{
					transaccionBCP.setTipo(true);
				}
				else 
				{
					transaccionBCP.setTipo(false);
				}
				System.out.println("Monto");
				saldo=entradaEscaner.nextInt();
				transaccionBCP.setMonto(saldo);
				transaccionesBCP.add(transaccionBCP);
				
			}
			else if(n==3)
				
			{
				mostrarTranferenciasBCP();
			}
			else if(n==4)
			{
				mostrarCuentasBCP();
			}
			
		}
		else if(opcion.equals("BBVA"))
		{
			
			fabricaBBVA = FactoryProducer.getFactory(opcion);
			cuentaBBVA = (BancoBBVA)fabricaBBVA.getCuenta(opcion);
			transaccionBBVA =(BBVA)fabricaBBVA.getBanco(opcion);
			if(n==2)
			{
				System.out.println("Ingrese un numero de cuenta");
				nro=entradaEscaner.nextLine();
				System.out.println("Ingrese el Saldo");
				saldo=entradaEscaner.nextInt();
				cuentaBBVA.setCuenta(nro);
				cuentaBBVA.setSaldo(saldo);
			}
			else if(n==1)
			{
				System.out.println("Desea realizar un deposito o un retiro");
				System.out.println("1- Realizar retiro");
				System.out.println("2- Registrar deposito");
				saldo=entradaEscaner.nextInt();
				if(saldo==1)
				{
					transaccionBBVA.setTipo(true);
				}
				else 
				{
					transaccionBBVA.setTipo(false);
				}
				System.out.println("Monto");
				saldo=entradaEscaner.nextInt();
				transaccionBBVA.setMonto(saldo);
				transaccionesBBVA.add(transaccionBBVA);
				cuentasBBVA.add(cuentaBBVA);
			}
			else if(n==3)
				
			{
				mostrarTransferenciasBBVA();
			}
			else if(n==4)
			{
				mostrarCuentasBBVA();
			}
		}
		notificacion();
		
	}
	public void mostrarCuentasBCP()
	{
		for(BancoBCP cuentaBCP: cuentasBCP)
		{
			cuentaBCP.mostrar();
		}
	}
	public void mostrarTranferenciasBCP()
	{
		for(BCP transBCP: transaccionesBCP)
		{
			transBCP.mostrar();
		}
	}
	
	public void mostrarCuentasBBVA()
	{
		for(BancoBBVA cuentaBBVA: cuentasBBVA)
		{
			cuentaBBVA.mostrar();
		}
	}
	public void mostrarTransferenciasBBVA()
	{
		for(BBVA transBBVA: transaccionesBBVA)
		{
			transBBVA.mostrar();
		}
	}
	public void notificacion()
	{
		Subject subject = new Subject();

		new SolObservadorBCP(subject);
		new SolObservadorBBVA(subject);
		
		System.out.println("Si desea cambiar 10 d�lares obtendr� : ");
		subject.setEstado(10);
		System.out.println("-----------------");
		
	}
	
	
	/*AbstractFactory banco= FactoryProducer.getFactory("BCP");
	
	BancoBCP banco10= (BancoBCP) banco.getCuenta("BCP");
	BCP banco11= (BCP)banco.getBanco("BCP");
	banco10.setCuenta("jjjkjq1233");
	banco10.setSaldo(67);
	banco11.setTipo(true);
	banco11.setMonto(1500);
	banco10.mostrar();
	banco11.mostrar();*/

}
