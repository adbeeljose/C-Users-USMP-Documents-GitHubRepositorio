package Main;

import Cuentas.*;
import Fabricas.*;
import Transacciones.*;

public class Fachada 
{
	private AbstractFactory fabricaBBVA;
	private AbstractFactory fabricaBCP;
	//private FactoryProducer producer = new FactoryProducer();
	private BancoBBVA cuentaBBVA;
	private BancoBCP cuentaBCP;
	private BBVA transaccionBBVA = new BBVA();
	private BCP transaccionBCP = new BCP();
	
	private ArrayList <>
	
	public Fachada()
	{}
	public void ingresarBanco(String opcion)
	{
		if(opcion.equals("BCP"))
		{
			fabricaBCP = FactoryProducer.getFactory(opcion);
			cuentaBCP = (BancoBCP)fabricaBCP.getCuenta(opcion);
			transaccionBCP =(BCP)fabricaBCP.getBanco(opcion);
			cuentaBCP.setCuenta("11111111");
			cuentaBCP.setSaldo(67);
			transaccionBCP.setTipo(false);
			transaccionBCP.setMonto(1500);
			cuentaBCP.mostrar();
			transaccionBCP.mostrar();
		}
		else if(opcion.equals("BBVA"))
		{
			fabricaBBVA = FactoryProducer.getFactory(opcion);
			cuentaBBVA = (BancoBBVA)fabricaBBVA.getCuenta(opcion);
			transaccionBBVA =(BBVA)fabricaBBVA.getBanco(opcion);
			cuentaBBVA.setCuenta("22222");
			cuentaBBVA.setSaldo(200);
			transaccionBBVA.setTipo(true);
			transaccionBBVA.setMonto(3000);
			cuentaBBVA.mostrar();
			transaccionBBVA.mostrar();
			
		}
	}
	
	/*AbstractFactory banco= FactoryProducer.getFactory("BCP");
	//Shape shape1 = shapeFactory.getShape("CIRCLE");
	BancoBCP banco10= (BancoBCP) banco.getCuenta("BCP");
	BCP banco11= (BCP)banco.getBanco("BCP");
	banco10.setCuenta("jjjkjq1233");
	banco10.setSaldo(67);
	banco11.setTipo(true);
	banco11.setMonto(1500);
	banco10.mostrar();
	banco11.mostrar();*/

}
