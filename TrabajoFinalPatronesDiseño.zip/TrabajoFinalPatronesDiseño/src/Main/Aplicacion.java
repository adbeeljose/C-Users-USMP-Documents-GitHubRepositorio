package Main;
import Cuentas.*; 
import Transacciones.*;
import Fabricas.*;

public class Aplicacion
{

	public static void main(String[] args)
	{
		Fachada fachada = new Fachada();
	/*	BancoBCP banco= new BancoBCP("8782", 17);
		ICuenta banco1= new BancoBBVA("1111", 20);
		
		banco.abonarsaldo(10);
		banco.mostrar();
		System.out.println("-------------");
		banco1.abonarsaldo(10);
		banco1.mostrar();
		System.out.println("-------------");
		
		IBanco banco5= new BCP(800, true);
		IBanco banco6= new BCP(1000, false);
		IBanco banco7= new BBVA(1000, false);
		
		banco5.mostrar();
		banco6.mostrar();
		banco7.mostrar();
		*/
		/*
		AbstractFactory banco= FactoryProducer.getFactory("BCP");
		//Shape shape1 = shapeFactory.getShape("CIRCLE");
		BancoBCP banco10= (BancoBCP) banco.getCuenta("BCP");
		BCP banco11= (BCP)banco.getBanco("BCP");
		banco10.setCuenta("jjjkjq1233");
		banco10.setSaldo(67);
		banco11.setTipo(true);
		banco11.setMonto(1500);
		banco10.mostrar();
		banco11.mostrar();*/
		
		fachada.ingresarBanco("BCP");
		fachada.ingresarBanco("BBVA");
		
	}

}
