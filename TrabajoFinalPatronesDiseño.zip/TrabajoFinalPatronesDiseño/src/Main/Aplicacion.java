package Main;
import Cuentas.*; 
import Transacciones.*;
import Fabricas.*;
import Observador.*;
import java.util.Scanner;
public class Aplicacion
{

	public static void main(String[] args)
	{
		//Scanner entradaEscaner = new Scanner (System.in);
		Fachada fachada = new Fachada();
		System.out.println("Muy buenas tardes al aplicativo de la banca");
		fachada.menu();
		
		
		
		
	}

}
